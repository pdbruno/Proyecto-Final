<div class="container-fluid">
    <div id="page-wrapper" style="height: 94%;">
        <div class="row">
            <a href="<?php echo URL; ?>cliente">abmClientes</a>
            <a href="<?php echo URL; ?>help/index/Actividades">abmActividades</a>
            <a href="<?php echo URL; ?>help/index/Sedes">abmSedes</a>
            <a href="<?php echo URL; ?>help/index/Localidades">abmLocalidades</a>
            <a href="<?php echo URL; ?>help/index/Distribuidores">abmDistribuidores</a>
            <a href="<?php echo URL; ?>producto/">abmProductos</a>

        </div>
    </div>
</divD