
<div class="container-fluid">
    <div id="page-wrapper">
        <div class="row">
            <h1>Error Lince</h1>
            <?php echo $this->msg; ?>
        </div>
    </div>
</div>