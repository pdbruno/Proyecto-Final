</div>

<div id="footer">
    
</div>


        <!-- Bootstrap Core JavaScript -->
        <script src="<?php echo URL; ?>views/vendor/bootstrap/js/bootstrap.min.js"></script>

        <!-- Metis Menu Plugin JavaScript -->
        <script src="<?php echo URL; ?>views/vendor/metisMenu/metisMenu.min.js"></script>

        <!-- DataTables JavaScript -->
        <script src="<?php echo URL; ?>views/vendor/datatables-plugins/dataTables.bootstrap.min.js"></script>
        <script src="<?php echo URL; ?>views/vendor/datatables-responsive/dataTables.responsive.js"></script>
        <script src="<?php echo URL; ?>views/dataTables.select.min.js"></script>
        <script src="<?php echo URL; ?>views/dataTables.scroller.min.js"></script>

        <!-- Custom Theme JavaScript -->
        <script src="<?php echo URL; ?>views/dist/js/sb-admin-2.js"></script>
</body>
</html>