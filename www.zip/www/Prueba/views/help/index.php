<div class="container-fluid">
    <div id="page-wrapper">
        <div class="row">
            <h1>Estas en la help</h1>
            me dijeron que te diga esto:
            <?php echo $this->blah;?>
        </div>
    </div>
</div>