<?php

define('URL', 'http://localhost/Prueba/');